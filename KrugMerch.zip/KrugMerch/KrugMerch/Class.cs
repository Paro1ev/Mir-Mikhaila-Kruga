﻿public class User
{
    public User()
    {
        ID = Guid.NewGuid().ToString();
    }

    public User(string name, string email, string passwordHash, string role)
    {
        ID = Guid.NewGuid().ToString();
        Name = name;
        Email = email;
        PasswordHash = passwordHash;
        Role = role;
    }

    public string ID { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string PasswordHash { get; set; }
    public string Role { get; set; }
}

public class Product
{
    public string ID { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public string Image { get; set; }

    public Product() { }

    public Product(string id, string name, string description, decimal price, string image)
    {
        ID = id;
        Name = name;
        Description = description;
        Price = price;
        Image = image;
    }
}

public class Order
{
    public Order()
    {
        ID = Guid.NewGuid().ToString();
        Date = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
    }

    public string ID { get; set; }
    public string UserID { get; set; }
    public string Date { get; set; }
    public string Status { get; set; }
}

public class OrderItem
{
    public OrderItem()
    {
        ID = Guid.NewGuid().ToString();
    }

    public string ID { get; set; }
    public string? OrderID { get; set; }
    public string UserID { get; set; }
    public string ProductID { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string ProductName { get; set; }
    public string ProductImage { get; set; }
}

public class CartItemRequest
{
    public string ProductId { get; set; }
    public int Quantity { get; set; }
}

public class UpdateQuantityRequest
{
    public int Quantity { get; set; }
}

public class Comment
{
    public string ID { get; set; } = Guid.NewGuid().ToString();
    public string Text { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string UserID { get; set; }
    public string ProductID { get; set; }
    public User User { get; set; }
    public Product Product { get; set; }
}

public class CommentRequest
{
    public string Text { get; set; }
}
