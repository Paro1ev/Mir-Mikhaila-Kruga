﻿public class UserDTO
{
    public string ID { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Email { get; set; }
    public string Role { get; set; }
    public string Password { get; set; }
}

public class ProductDTO
{
    public string ID { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public string Image { get; set; }
}

public class CartItemDTO
{
    public string ID { get; set; } = Guid.NewGuid().ToString();
    public string UserID { get; set; }
    public string ProductID { get; set; }
    public int Quantity { get; set; }
}

public class OrderDTO
{
    public string ID { get; set; }
    public string UserID { get; set; }
    public string OrderDate { get; set; } = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
    public string Status { get; set; }
}

public class OrderItemDTO
{
    public string ID { get; set; }
    public string OrderID { get; set; }
    public string UserID { get; set; }
    public string ProductID { get; set; }
    public string ProductName { get; set; }
    public string ProductImage { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}
