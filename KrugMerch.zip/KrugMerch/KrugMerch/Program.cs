using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Text.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap.Clear();
JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

var builder = WebApplication.CreateBuilder(args);

var key = Encoding.ASCII.GetBytes("super_secret_jwt_key_that_is_very_long_123456");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;
        options.SaveToken = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateIssuer = false,
            ValidateAudience = false,
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite("Data Source=app.db"));

builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy =>
        {
            policy.AllowAnyOrigin()
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        });
});

var app = builder.Build();

app.UseCors("AllowAll");

using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    dbContext.Database.EnsureCreated();
}

app.MapGet("/users", async (IRepository<User> repo) =>
{
    try
    {
        var users = await repo.GetAllAsync();
        return Results.Ok(users);
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка при получении пользователей: " + ex.Message);
    }
});

app.MapPost("/users", async (IRepository<User> repo, User user) =>
{
    try
    {
        if (string.IsNullOrEmpty(user.ID) || string.IsNullOrEmpty(user.Name) || string.IsNullOrEmpty(user.Email))
        {
            return Results.BadRequest("Некорректные данные. ID, Name и Email обязательны.");
        }

        await repo.AddAsync(user);
        return Results.Ok(user);
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка при добавлении пользователя: " + ex.Message);
    }
});

app.MapGet("/users/{id}", async (IRepository<User> repo, string id) =>
{
    try
    {
        var user = await repo.GetByIdAsync(id);
        return user != null ? Results.Ok(user) : Results.NotFound("Пользователь не найден.");
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка при поиске пользователя: " + ex.Message);
    }
});

app.MapDelete("/users/{id}", async (IRepository<User> repo, string id) =>
{
    try
    {
        var user = await repo.GetByIdAsync(id);
        if (user == null)
        {
            return Results.NotFound("Пользователь не найден.");
        }

        await repo.DeleteAsync(id);
        return Results.Ok($"Пользователь {id} удален.");
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка при удалении пользователя: " + ex.Message);
    }
});

app.MapGet("/products", async (IRepository<Product> repo) =>
{
    var products = await repo.GetAllAsync();
    return Results.Ok(products);
});

app.MapGet("/products/{id}", async (IRepository<Product> repo, string id) =>
{
    var product = await repo.GetByIdAsync(id);
    return product != null ? Results.Ok(product) : Results.NotFound("Товар не найден.");
});

app.MapPost("/products", async (IRepository<Product> repo, Product product) =>
{
    if (string.IsNullOrEmpty(product.Name) || product.Price <= 0)
    {
        return Results.BadRequest("Некорректные данные о товаре.");
    }

    await repo.AddAsync(product);
    return Results.Ok(product);
});

app.MapPut("/products/{id}", async (IRepository<Product> repo, string id, Product updatedProduct) =>
{
    var existingProduct = await repo.GetByIdAsync(id);
    if (existingProduct == null)
    {
        return Results.NotFound("Товар не найден.");
    }

    existingProduct.Name = updatedProduct.Name;
    existingProduct.Description = updatedProduct.Description;
    existingProduct.Price = updatedProduct.Price;
    existingProduct.Image = updatedProduct.Image;

    await repo.UpdateAsync(existingProduct);
    return Results.Ok(existingProduct);
});

app.MapDelete("/products/{id}", async (IRepository<Product> repo, string id) =>
{
    var product = await repo.GetByIdAsync(id);
    if (product == null)
    {
        return Results.NotFound("Товар не найден.");
    }

    await repo.DeleteAsync(id);
    return Results.Ok("Товар удален.");
});

app.MapPost("/register", async (IRepository<User> repo, User user) =>
{
    if (string.IsNullOrEmpty(user.Email) || string.IsNullOrEmpty(user.PasswordHash))
    {
        return Results.BadRequest("Email и пароль обязательны.");
    }

    var existingUser = (await repo.GetAllAsync()).FirstOrDefault(u => u.Email == user.Email);
    if (existingUser != null)
    {
        return Results.BadRequest("Пользователь с таким Email уже существует.");
    }

    user.ID = Guid.NewGuid().ToString();
    user.PasswordHash = AuthService.HashPassword(user.PasswordHash);

    if (!(await repo.GetAllAsync()).Any())
    {
        user.Role = "admin";
    }
    else
    {
        user.Role = "user";
    }

    await repo.AddAsync(user);
    return Results.Ok("Регистрация успешна!");
});

app.MapPost("/login", async (IRepository<User> repo, UserDTO loginData) =>
{
    try
    {
        if (string.IsNullOrEmpty(loginData.Email) || string.IsNullOrEmpty(loginData.Password))
        {
            return Results.BadRequest("Email и пароль обязательны.");
        }

        var user = (await repo.GetAllAsync()).FirstOrDefault(u => u.Email == loginData.Email);
        if (user == null)
        {
            return Results.BadRequest("Пользователь не найден.");
        }

        if (!AuthService.VerifyPassword(loginData.Password, user.PasswordHash))
        {
            return Results.BadRequest("Неверный пароль.");
        }

        var token = AuthService.GenerateJwtToken(user);
        return Results.Ok(new { Token = token, User = user });
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка входа: {ex.Message}");
        return Results.Problem($"Ошибка входа: {ex.Message}");
    }
});

app.MapPost("/cart/add", async (HttpContext context, AppDbContext db) =>
{
    try
    {
        var data = await context.Request.ReadFromJsonAsync<CartItemRequest>();
        var userId = context.User.FindFirstValue("nameid");

        if (string.IsNullOrEmpty(userId))
            return Results.Unauthorized();

        var product = await db.Products.FindAsync(data.ProductId);
        if (product == null)
            return Results.NotFound("Товар не найден");

        var orderItem = new OrderItem
        {
            ID = Guid.NewGuid().ToString(),
            UserID = userId,
            ProductID = data.ProductId,
            Quantity = data.Quantity,
            Price = product.Price,
            ProductName = product.Name,
            ProductImage = product.Image ?? "https://via.placeholder.com/100",
            OrderID = null
        };

        db.OrderItems.Add(orderItem);
        await db.SaveChangesAsync();

        return Results.Ok(orderItem);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapGet("/cart", async (HttpContext context, AppDbContext db) =>
{
    var userId = context.User.Claims
        .FirstOrDefault(c => c.Type == "nameid")?.Value;

    Console.WriteLine($"🆔 UserID из токена: {userId}");

    if (string.IsNullOrEmpty(userId))
    {
        Console.WriteLine("❌ UserID не найден в токене!");
        return Results.BadRequest("Ошибка авторизации");
    }

    try
    {
        var cartItems = await db.OrderItems
            .Where(o => o.OrderID == null && o.UserID == userId)
            .Select(o => new
            {
                id = o.ID,
                productId = o.ProductID,
                quantity = o.Quantity,
                price = o.Price,
                productName = o.ProductName,
                productImage = o.ProductImage
            })
            .ToListAsync();

        Console.WriteLine($"🛒 Найдено {cartItems.Count} товаров для пользователя {userId}");
        return Results.Ok(cartItems);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"🔥 Ошибка БД: {ex.Message}");
        return Results.Problem("Ошибка сервера");
    }
});

app.MapDelete("/cart/remove/{id}", async (string id, HttpContext context, AppDbContext db) =>
{
    var user = context.User;
    if (!user.Identity.IsAuthenticated)
        return Results.Unauthorized();

    var item = await db.OrderItems.FirstOrDefaultAsync(o => o.ID == id && o.OrderID == null);
    if (item == null)
        return Results.NotFound("Товар не найден");

    db.OrderItems.Remove(item);
    await db.SaveChangesAsync();

    return Results.Ok(new { message = "Товар удалён" });
});

app.MapPost("/cart/checkout", async (HttpContext context, AppDbContext db) =>
{
    var userId = context.User.FindFirstValue("nameid");
    if (string.IsNullOrEmpty(userId))
        return Results.Unauthorized();

    var cartItems = await db.OrderItems
        .Where(o => o.OrderID == null && o.UserID == userId)
        .ToListAsync();

    if (!cartItems.Any())
        return Results.BadRequest("Корзина пуста");

    var order = new Order
    {
        ID = Guid.NewGuid().ToString(),
        UserID = userId,
        Date = DateTime.UtcNow.ToString("o"),
        Status = "Новый"
    };

    foreach (var item in cartItems)
    {
        item.OrderID = order.ID;
    }

    await db.Orders.AddAsync(order);
    await db.SaveChangesAsync();

    return Results.Ok(new
    {
        OrderId = order.ID,
        Status = order.Status,
        Total = cartItems.Sum(i => i.Price * i.Quantity)
    });
});

app.MapPut("/cart/update/{id}", async (string id, AppDbContext db, HttpContext context) =>
{
    var data = await context.Request.ReadFromJsonAsync<UpdateQuantityRequest>();
    var userId = context.User.FindFirstValue("nameid");

    var item = await db.OrderItems
        .FirstOrDefaultAsync(o => o.ID == id && o.UserID == userId && o.OrderID == null);
    if (item == null) return Results.NotFound();

    item.Quantity = data.Quantity;
    await db.SaveChangesAsync();

    return Results.Ok(item);
});

app.MapGet("/orders", async (HttpContext context, AppDbContext db) =>
{
    var userId = context.User.FindFirstValue("nameid");
    if (string.IsNullOrEmpty(userId))
        return Results.Unauthorized();

    var orders = await db.Orders
        .Where(o => o.UserID == userId)
        .Select(o => new
        {
            o.ID,
            o.Date,
            o.Status,
            Items = db.OrderItems
                .Where(i => i.OrderID == o.ID)
                .Select(i => new
                {
                    i.ProductName,
                    i.Quantity,
                    i.Price
                }).ToList()
        })
        .ToListAsync();

    return Results.Ok(orders);
});

app.MapGet("/products/{productId}/comments", async (HttpContext context, AppDbContext db, string productId) =>
{
    var userId = context.User.FindFirstValue("nameid");

    var comments = await db.Comments
        .Include(c => c.User)
        .Where(c => c.ProductID == productId)
        .OrderByDescending(c => c.CreatedAt)
        .Select(c => new
        {
            c.ID,
            c.Text,
            c.CreatedAt,
            UserId = c.UserID,
            UserName = c.User.Name,
            IsAuthor = c.UserID == userId
        })
        .ToListAsync();

    return Results.Ok(comments);
});

app.MapPost("/products/{productId}/comments", async (HttpContext context, AppDbContext db, string productId, CommentRequest request) =>
{
    var userId = context.User.FindFirstValue("nameid");
    if (string.IsNullOrEmpty(userId)) return Results.Unauthorized();

    var product = await db.Products.FindAsync(productId);
    if (product == null) return Results.NotFound("Товар не найден");

    var comment = new Comment
    {
        Text = request.Text,
        UserID = userId,
        ProductID = productId
    };

    db.Comments.Add(comment);
    await db.SaveChangesAsync();

    return Results.Ok(comment);
});

app.MapDelete("/comments/{id}", async (HttpContext context, AppDbContext db, string id) =>
{
    var userId = context.User.FindFirstValue("nameid");
    var isAdmin = context.User.IsInRole("admin");

    var comment = await db.Comments.FindAsync(id);
    if (comment == null) return Results.NotFound();

    if (comment.UserID != userId && !isAdmin)
        return Results.Forbid();

    db.Comments.Remove(comment);
    await db.SaveChangesAsync();

    return Results.Ok();
});

app.UseAuthentication();
app.UseAuthorization();
app.UseDeveloperExceptionPage();
app.Run();
